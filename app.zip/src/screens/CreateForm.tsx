import { useMutation, useQuery } from "@apollo/client";
import { Field, Form, Formik } from "formik";
import React, { useEffect, useState } from "react";
import { CREATE_FORM, GET_FORMS } from "../app_constants/Mutations";
import FormTile from "../components/FormTile";

const CreateForm = () => {
  // Queries
  var token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwibmFtZSI6IkRlbW8gRm9ybSIsImlhdCI6MTY4MzE5NjU2OCwiZXhwIjoxNjgzMjAwMTY4fQ.73I7aNDrSQctgezbkoIY_qgvjVHMNAr3AM1ddjNebIs'
  const [createForm] = useMutation(CREATE_FORM);
  const { loading, error, data,refetch } = useQuery(GET_FORMS, {
    context: {
      headers: {
        authorization: `Bearer ${token}`,
      },
    },
  });

  const initialValues = {
    title: "",
    description: "",
  };

  useEffect(() => {
    refetch();
  });

  const [showDialog, setShowDialog] = useState(false);

  const onSubmit = async (
    values: { title: string; description: string },
    { resetForm }: any
  ) => {
    console.log(values.title + " " + values.description);
    try {
      const { data } = await createForm({
        variables: {
          title: values.title,
          description: values.description,
        },
      });
      console.log("Form created:", data.createForm);
      resetForm();
      refetch();
      setShowDialog(false);
    } catch (error) {
      console.error("Failed to create form:", error);
    }
  };

  return (
    <div
      style={{ display: "flex", flexDirection: "column", alignItems: "center" }}
    >
      <h2 style={{ marginTop: "32px", marginBottom: "16px" }}>
        Available Forms
      </h2>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>Error: {error.message}</p>
      ) : (
        <div style={{ display: "flex", flexWrap: "wrap" }}>
          {data.forms.map((form: any) => (
            <FormTile key={form.id} data={form} />
          ))}
        </div>
      )}
    </div>
  );
};

export default CreateForm;
