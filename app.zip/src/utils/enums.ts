export enum ItemType{
    Date, Text
}