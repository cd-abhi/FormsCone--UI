import { useMutation, gql } from '@apollo/client';

export const CREATE_FORM = gql`
  mutation createForm($title: String!, $description: String!) {
    createForm(input: { title: $title, description: $description }) {
      result
    }
  }
`;

export const GET_FORMS = gql`
  query {
    forms {
      id
      title
      description
    }
  }
`;

export const DELETE_FORM = gql`
  mutation DeleteForm($id: Float!) {
    deleteForm(id: $id)
  }
`;

// export const ADD_FORMS_ITEMS = gql`
//   mutation CreateForm($fields: [FieldInput]) {
//     createForm(fields: $fields) {
//       id
//       name
//       fields {
//         id
//         label
//         type
//         required
//       }
//     }
//   }
// `;

// export const CREATE_SINGLE_ITEM = gql`
//   mutation createSingleItem($question: String!, $description: String!) {
//     createItem(input: { question: $question, description: $description }) {
//       id
//       question
//       description
//     }
//   }
// `;

export const ADD_ITEMS = gql`
  mutation addItems($input: [ItemsInputType!]!) {
    addItems(input: $input) {
      result
    }
  }
`;

export const ADD_FORM_ITEMS_MUTATION = gql`
  mutation AddFormItems($formId: ID!, $fieldset: [FormItemInput!]!) {
    addFormItems(formId: $formId, fieldset: $fieldset) {
      id
      question
      description
    }
  }
`;